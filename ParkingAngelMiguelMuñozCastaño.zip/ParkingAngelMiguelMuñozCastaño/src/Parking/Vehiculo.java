package Parking;

public class Vehiculo {

	private String matricula ;
	private String modelo ;
	private String color ;
	private Tipo tipo ;
	
	public enum Tipo {
		furgoneta,deportivo,motos,camion,turismo
	}
	
	//Constructor
	public Vehiculo (String matricula , String modelo,String color , Tipo tipo) 
	{
		this.matricula=matricula;
		this.modelo=modelo ;
		this.color=color ;
		this.tipo= tipo ;
	}
	
	//Getters & Setters
	public String getMatricula() {
		return matricula;
	}
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public Tipo getTipo() {
		return tipo;
	}
	public void setTipo(Tipo tipo) {
		this.tipo = tipo;
	}
	@Override
	//Metodo toString 
	public String toString () 
	{
		String cadena = "";
		cadena = "Matricula : "+matricula+" Modelo : "+modelo+" Color : "+color+" Tipo : "+tipo;
		return cadena ;
	}

}
