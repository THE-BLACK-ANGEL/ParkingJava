package Parking;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import Parking.Vehiculo.Tipo;

public class Parking {

    public static void main(String[] args) {

        ArrayList<Vehiculo> Parking = new ArrayList<>();
        Scanner entrada = new Scanner(System.in);

        operaciones(Parking, entrada);

        System.out.println("Muchas gracias por usar el programa de gestión del parking.");
        entrada.close();
    }

    public static void operaciones(ArrayList<Vehiculo> Parking, Scanner entrada) {
        int num = 0;

        do {
            try {
                System.out.print("\t==OPERACIONES PARKING==\n"
                        + "1. Añadir un vehículo.\n"
                        + "2. Pedir información de una plaza del parking.\n"
                        + "3. Pedir lista de vehículos estacionados.\n"
                        + "4. Pedir lista de furgonetas estacionadas.\n"
                        + "5. Quitar un vehículo del parking.\n"
                        + "6. Generar archivo de texto con los vehículos en el parking.\n"
                        + "7. Coger informacion de los vehiculos en el parking de un documento de texto.\n"
                        + "8. Salir.\n"
                        + "OPERACIÓN ELEGIDA = ");
                num = entrada.nextInt();
                entrada.nextLine();

                switch (num) {
                    case 1 -> añadirVehiculo(Parking, entrada);
                    case 2 -> mostrarInformacion(Parking, entrada);
                    case 3 -> vehiculosEstacionados(Parking);
                    case 4 -> furgonetasEstacionadas(Parking);
                    case 5 -> eliminarVehiculo(Parking, entrada);
                    case 6 -> imprimirDatosParking(Parking);
                    case 7 -> cogerDatosParking(Parking);
                    case 8 -> System.out.println("Saliendo del programa...");
                    default -> System.out.println("Introduzca un número válido.");
                }
                System.out.println();
            } catch (Exception e) {
                System.out.println("Error: Entrada no válida.");
                entrada.nextLine();
            }
        } while (num != 8);
    }

    private static void imprimirDatosParking(ArrayList<Vehiculo> parking) {
        try (FileWriter writer = new FileWriter("parking_datos.txt")) {
            for (int i = 0; i < parking.size(); i++) {
                writer.write("===Plaza " + (i + 1) + "===\n " + parking.get(i).toString() + "\n");
            }
            System.out.println("Los datos del parking han sido guardados en 'parking_datos.txt'.");
        } catch (IOException e) {
            System.out.println("Error al escribir en el archivo.");
        }
    }

    private static void eliminarVehiculo(ArrayList<Vehiculo> parking, Scanner entrada) {
        System.out.print("Introduce la matrícula del vehículo a eliminar: ");
        String matricula = entrada.nextLine();
        boolean eliminado = parking.removeIf(v -> v.getMatricula().equalsIgnoreCase(matricula));
        if (eliminado) {
            System.out.println("Vehículo con matrícula " + matricula + " eliminado.");
        } else {
            System.out.println("No se encontró un vehículo con esa matrícula.");
        }
    }

    private static void furgonetasEstacionadas(ArrayList<Vehiculo> parking) {
        System.out.println("== Furgonetas estacionadas ==");
        parking.stream().filter(v -> v.getTipo() == Tipo.furgoneta).forEach(v -> System.out.println(v.toString()));
    }

    private static void vehiculosEstacionados(ArrayList<Vehiculo> Parking) {
        if (Parking.isEmpty()) {
            System.out.println("El parking está vacío.");
        } else {
        	int i = 1;
            for (
            		Vehiculo v:Parking) {
            	
                System.out.println("\nPlaza " + (i) + ": \n"+v.toString()+"\n");
                i++;
            }
        }
    }

    public static void añadirVehiculo(ArrayList<Vehiculo> Parking, Scanner entrada) {
        try {
            System.out.print("Introduce la matrícula del vehículo: ");
            String matricula = entrada.nextLine();

            System.out.print("Introduce el modelo del vehículo: ");
            String modelo = entrada.nextLine();

            System.out.print("Introduce el color del vehículo: ");
            String color = entrada.nextLine();

            System.out.print("Introduce el tipo de vehículo (furgoneta, deportivo, motos, turismo): ");
            String tipo = entrada.nextLine();

            Vehiculo vehiculo = new Vehiculo(matricula, modelo, color, Tipo.valueOf(tipo.toLowerCase()));
            Parking.add(vehiculo);
            System.out.println("Vehículo añadido correctamente.");
        } catch (IllegalArgumentException e) {
            System.out.println("Error: tipo de vehículo no válido.");
        } catch (Exception e) {
            System.out.println("No se pudo añadir el vehículo. Inténtalo de nuevo.");
        }
    }

    private static void mostrarInformacion(ArrayList<Vehiculo> Parking, Scanner entrada) {
        System.out.print("Introduce el número de plaza: ");
        int num;
        try {
            num = entrada.nextInt() - 1;
            if (num >= 0 && num < Parking.size()) {
                System.out.println(Parking.get(num).toString());
            } else {
                System.out.println("Número de plaza no válido.");
            }
        } catch (Exception e) {
            System.out.println("Entrada no válida.");
            entrada.nextLine();
        }
    }
    
    private static void cogerDatosParking (ArrayList<Vehiculo> Parking) {
    	String l= "";
    	String val [];
    	try (BufferedReader br = new BufferedReader(new FileReader("cogerDatos.txt"))){
			
    		while((l=br.readLine())!=null) 
    		{
    			
    			val = l.split(", ");
    			Vehiculo v = new Vehiculo(val[0],val[1],val[2],Tipo.valueOf(val[3].toLowerCase()));
    			Parking.add(v);
    			
    		}
    		System.out.println("Se han cogido los vehiculos correctamente");
    	}	
    	catch(IOException e) 
    	{
    		
    		System.out.println("No se ha encontrado el archivo");
    		
		} catch (Exception e) {
			e.printStackTrace();
		}
    	
    	
    }
}
