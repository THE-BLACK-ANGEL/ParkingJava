package Parking;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import Parking.Vehiculo.Tipo;

public class Parking {

	//Main
    public static void main(String[] args) {

        ArrayList<Vehiculo> Parking = new ArrayList<>();
        Scanner entrada = new Scanner(System.in);

        operaciones(Parking, entrada);

        System.out.println("Muchas gracias por usar el programa de gestión del parking.");
        entrada.close();
    }
    
    //Metodo para seleccionar las operaciones que haremos en la aplicacion
    public static void operaciones(ArrayList<Vehiculo> Parking, Scanner entrada) {
        int num = 0;

        do {
            try {
            	
                System.out.print("\t==OPERACIONES PARKING==\n"
                        + "1. Añadir un vehículo.\n"
                        + "2. Pedir información de una plaza del parking.\n"
                        + "3. Pedir lista de vehículos estacionados.\n"
                        + "4. Pedir lista de furgonetas estacionadas.\n"
                        + "5. Quitar un vehículo del parking.\n"
                        + "6. Imprimir documento con los vehículos en el parking.\n"
                        + "7. Salir.\n"
                        + "OPERACIÓN ELEGIDA = ");
                num = entrada.nextInt();

                switch (num) {
                    case 1 -> añadirVehiculo(Parking, entrada);
                    case 2 -> mostrarInformacion(Parking, entrada);
                    case 3 -> vehiculosEstacionados(Parking);
                    case 4 -> furgonetasEstacionadas(Parking);
                    case 5 -> eliminarVehiculo(Parking, entrada);
                    case 6 -> imprimirDatosParking(Parking);
                    case 7 -> añadirVehiculosPorTXT(Parking);
                    case 8 -> System.out.println("Saliendo del programa...");
                    default -> System.out.println("Introduzca un número válido.");
                }
                
                System.out.println();
            } catch (Exception e) {
                System.out.println("Entrada no válida.");
            }
        } while (num != 7);
    }
    
    //Metodo para imprimir en un documento txt los datos del programa de gestion del parking
    public static void imprimirDatosParking(ArrayList<Vehiculo> parking) {
        try (BufferedWriter writer = new BufferedWriter( new FileWriter("parking_datos.txt"))) {
            
        	for (int i = 0; i < parking.size(); i++) {
                writer.write("===Plaza " + (i + 1) + "===\n " + parking.get(i).toString() + "\n");
            
            }
        	
            System.out.println("Los datos del parking han sido guardados en 'parking_datos.txt'.");
        } catch (IOException e) {
            System.out.println("Error al escribir en el archivo.");
        }
    }
    
    //Metodo para eliminar un vehiculo por su matricula
    public static void eliminarVehiculo(ArrayList<Vehiculo> parking, Scanner entrada) {
        System.out.print("Introduce la matrícula del vehículo a eliminar: ");
        String matricula = entrada.nextLine();
        boolean eliminado = parking.removeIf(v -> v.getMatricula().equalsIgnoreCase(matricula));
        if (eliminado) {
            System.out.println("Vehículo con matrícula " + matricula + " eliminado.");
        } else {
            System.out.println("No se encontró un vehículo con esa matrícula.");
        }
    }
    
    //Metodo para mostrar las furgonetas que estan estacionadas en el parking
    public static void furgonetasEstacionadas(ArrayList<Vehiculo> parking) {
        System.out.println("== Furgonetas estacionadas ==");
        parking.stream().filter(v -> v.getTipo() == Tipo.furgoneta).forEach(v -> System.out.println(v.toString()));
    }
    
    //Metodo para mostrar todos los vehiculos que hay en el parking
    public static void vehiculosEstacionados(ArrayList<Vehiculo> Parking) {
        if (Parking.isEmpty()) {
            System.out.println("El parking está vacío.");
        } else {
            for (int i = 0; i < Parking.size(); i++) {
                System.out.println("Plaza " + (i + 1) + ": " + Parking.get(i).toString());
            }
        }
    }
    
    //Metodo para añadir un vehiculo al parking
    public static void añadirVehiculo(ArrayList<Vehiculo> Parking, Scanner entrada) {
        try {
            System.out.print("Introduce la matrícula del vehículo: ");
            String matricula = entrada.nextLine();

            System.out.print("Introduce el modelo del vehículo: ");
            String modelo = entrada.nextLine();

            System.out.print("Introduce el color del vehículo: ");
            String color = entrada.nextLine();

            System.out.print("Introduce el tipo de vehículo (furgoneta, deportivo, motos, turismo): ");
            String tipo = entrada.nextLine();

            Vehiculo vehiculo = new Vehiculo(matricula, modelo, color, Tipo.valueOf(tipo.toLowerCase()));
            Parking.add(vehiculo);
            System.out.println("Vehículo añadido correctamente.");
            
        } catch (IllegalArgumentException e) {
            System.out.println("tipo de vehículo no válido.");
        } catch (Exception e) {
            System.out.println("No se pudo añadir el vehículo. Inténtalo de nuevo.");
        }
    }
    
    //Metodo para mostrar informacion de una plaza en particular
    public static void mostrarInformacion(ArrayList<Vehiculo> Parking, Scanner entrada) {
        System.out.print("Introduce el número de plaza: ");
        int num;
        try {
            
        	num = entrada.nextInt() - 1;
            if (num >= 0 && num < Parking.size()) {
                System.out.println(Parking.get(num).toString());
            } else {
                System.out.println("Numero de plaza no valido.");
            }
            
        } catch (Exception e) {
            System.out.println("Entrada no valida.");
        }
    }
    
    //Metodo para meter vehuculos a partir de un archivo de texto 
    public static void añadirVehiculosPorTXT(ArrayList<Vehiculo> Parking) {
    	
    	try (BufferedReader reader = new BufferedReader (new FileReader("plazasNuevas.txt"))){
    		String linea="";
    		while(reader.readLine()!=null) {
    			
    			linea = reader.readLine();
    			String variables []=linea.split(", ");
    			String matricula = variables[0];
    			String modelo = variables[1];
    			String color = variables[2];
    			String tipo = variables[3];
    			
    			Vehiculo v = new Vehiculo (matricula, modelo, color, Tipo.valueOf(tipo.toLowerCase()));
    			Parking.add(v);
    			
    		}
			
		} catch (IOException e) {
			System.out.println("No se ha podido encontrar el archivo.");
		} catch (IllegalArgumentException e) {
			System.out.println("Tipo de vehiculo no valido");
		}
		
	}
    
}
