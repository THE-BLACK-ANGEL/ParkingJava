package Parking;

import java.util.ArrayList;
import java.util.Scanner;

public class Parking 
{

	public static void main(String[] args)
	{
		//Creamos el parking en el que vamos a almacenar los vehiculos 
		ArrayList<Vehiculo> Parking = new ArrayList<Vehiculo>();
		Scanner entrada = new Scanner (System.in);
		int num = 0 ;
		
		try {
			do {
				
				System.out.print("\t==OPERACIONES PARKING==\n"
						+"1.Pedir Informacion de una plaza del parking.\n"
						+"2.Pedir lista de vehiculos estacionados.\n"
						+"3.Pedir lista de furgonetas estacionadas.\n"
						+"4.Quitar coches del parking.\n"
						+"5.Imprimir documento con los coches en el parking.\n"
						+"6.Salir.\n"
						+"OPERACION ELEGIDA = ");
				num=entrada.nextInt();
				switch(num) 
				{
				
					case 1 ->{}
					case 2 ->{}
					case 3 ->{}
					case 4 ->{}
					case 5 ->{}
					case 6 ->{}
					default->{
						System.out.println("Introduzca otro numero de operación");
					}
				}
				System.out.println();
			
			} while(num!=6);
		} catch (Exception e) {
			
			
		}
		
		
		
	}

}
